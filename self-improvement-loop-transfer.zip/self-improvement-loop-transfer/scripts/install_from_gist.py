#!/usr/bin/env python3
"""Install a Codex skill from a GitHub repository/Gist or local bundle."""

from __future__ import annotations

import argparse
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Optional
from urllib.parse import urlsplit, urlunsplit


SKILL_NAME_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
FRONTMATTER_RE = re.compile(
    r"\A---\r?\n(?P<body>.*?)\r?\n---(?:\r?\n|\Z)", re.DOTALL
)
NAME_RE = re.compile(r"(?m)^name:\s*[\"']?([a-z0-9-]+)[\"']?\s*$")


class InstallError(Exception):
    """Expected, user-actionable installation error."""


def normalize_source_url(value: str) -> str:
    """Normalize a GitHub repository or Gist clone URL without credentials."""
    value = value.strip()
    if not value:
        raise InstallError("source URL is empty")

    if value.startswith("git@gist.github.com:"):
        return value if value.endswith(".git") else value + ".git"

    parsed = urlsplit(value)
    host = parsed.netloc.lower()
    if parsed.scheme != "https" or host not in {
        "gist.github.com",
        "www.gist.github.com",
        "github.com",
        "www.github.com",
    }:
        raise InstallError(
            "expected an HTTPS GitHub repository or Gist URL"
        )
    if parsed.username or parsed.password:
        raise InstallError("do not put GitHub credentials or tokens in the URL")
    if parsed.query or parsed.fragment:
        raise InstallError("source clone URL must not contain a query or fragment")

    path = parsed.path.rstrip("/")
    if not path:
        raise InstallError("source URL does not contain a repository or gist id")

    if host in {"github.com", "www.github.com"}:
        parts = path.lstrip("/").split("/")
        if len(parts) != 2 or not all(parts):
            raise InstallError(
                "GitHub repository URL must look like "
                "https://github.com/<owner>/<repo>.git; use --ref for a branch"
            )
        owner, repository = parts
        if repository.endswith(".git"):
            repository = repository[:-4]
        if not owner or not repository:
            raise InstallError("GitHub repository URL has an empty owner or name")
        return urlunsplit(
            ("https", "github.com", f"/{owner}/{repository}.git", "", "")
        )
    if not path.endswith(".git"):
        path += ".git"
    return urlunsplit(("https", parsed.netloc, path, "", ""))


def normalize_gist_url(value: str) -> str:
    """Backward-compatible alias for the former Gist-only helper."""
    return normalize_source_url(value)


def read_skill_name(skill_file: Path) -> str:
    """Read and minimally validate the required SKILL.md frontmatter."""
    try:
        content = skill_file.read_text(encoding="utf-8")
    except OSError as exc:
        raise InstallError(f"cannot read {skill_file}: {exc}") from exc

    match = FRONTMATTER_RE.match(content)
    if not match:
        raise InstallError("SKILL.md has no valid YAML frontmatter")

    name_match = NAME_RE.search(match.group("body"))
    if not name_match:
        raise InstallError("SKILL.md frontmatter has no valid name")

    name = name_match.group(1)
    if not SKILL_NAME_RE.fullmatch(name):
        raise InstallError(f"invalid skill name: {name}")
    return name


def locate_skill(source: Path) -> Path:
    """Find the single skill root in a bundle checkout."""
    root_skill = source / "SKILL.md"
    if root_skill.is_file():
        return source

    candidates = sorted(
        path.parent
        for path in source.rglob("SKILL.md")
        if ".git" not in path.parts
    )
    unique_candidates = list(dict.fromkeys(candidates))
    if len(unique_candidates) != 1:
        if not unique_candidates:
            raise InstallError("bundle does not contain SKILL.md")
        raise InstallError(
            "bundle contains multiple SKILL.md files; put one skill at the root "
            "or pass --source for a checkout containing one skill"
        )
    return unique_candidates[0]


def default_skills_root() -> Path:
    codex_home = os.environ.get("CODEX_HOME")
    if codex_home:
        return Path(codex_home).expanduser() / "skills"
    return Path("~/.codex/skills").expanduser()


def install_skill(
    source: Path,
    destination_root: Path,
    requested_name: Optional[str],
    dry_run: bool,
) -> Path:
    source = source.expanduser().resolve()
    if not source.is_dir():
        raise InstallError(f"source directory does not exist: {source}")

    skill_root = locate_skill(source)
    detected_name = read_skill_name(skill_root / "SKILL.md")
    name = requested_name or detected_name
    if not SKILL_NAME_RE.fullmatch(name):
        raise InstallError(f"invalid target skill name: {name}")

    destination_root = destination_root.expanduser()
    destination = destination_root / name
    if destination.exists():
        raise InstallError(
            f"destination already exists: {destination}; refusing to overwrite"
        )

    if dry_run:
        print(f"Would install {name} from {skill_root} to {destination}")
        return destination

    destination_root.mkdir(parents=True, exist_ok=True)
    shutil.copytree(
        skill_root,
        destination,
        ignore=shutil.ignore_patterns(".git"),
    )
    print(f"Installed {name} to {destination}")
    return destination


def clone_and_install(
    source_url: str,
    destination_root: Path,
    requested_name: Optional[str],
    dry_run: bool,
    ref: Optional[str],
) -> Path:
    normalized_url = normalize_source_url(source_url)
    with tempfile.TemporaryDirectory(prefix="codex-source-") as temporary:
        checkout = Path(temporary) / "source"
        clone_command = ["git", "clone", "--depth", "1"]
        if ref:
            clone_command.extend(["--branch", ref])
        clone_command.extend(["--quiet", normalized_url, str(checkout)])
        try:
            subprocess.run(
                clone_command,
                check=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError as exc:
            raise InstallError("git is required for URL-based installation") from exc
        except subprocess.CalledProcessError as exc:
            detail = (exc.stderr or "").strip()
            raise InstallError(f"git clone failed{': ' + detail if detail else ''}") from exc
        return install_skill(checkout, destination_root, requested_name, dry_run)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Install a Codex skill from a GitHub repository, Gist, or local bundle."
    )
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument(
        "source_url",
        nargs="?",
        help="HTTPS GitHub repository or Gist clone URL",
    )
    source.add_argument(
        "--source",
        type=Path,
        help="already cloned repository or bundle directory",
    )
    parser.add_argument(
        "--dest",
        type=Path,
        default=default_skills_root(),
        help="skills root (default: CODEX_HOME/skills or ~/.codex/skills)",
    )
    parser.add_argument(
        "--name",
        help="override the skill name from SKILL.md",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="validate and show the destination without copying",
    )
    parser.add_argument(
        "--ref",
        help="branch or tag to clone from a GitHub repository",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    try:
        if args.source is not None:
            install_skill(args.source, args.dest, args.name, args.dry_run)
        else:
            clone_and_install(
                args.source_url, args.dest, args.name, args.dry_run, args.ref
            )
    except InstallError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
