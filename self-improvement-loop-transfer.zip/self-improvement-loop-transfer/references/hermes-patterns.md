# Hermes Self-Improvement Pattern

Hermes Agent's self-improvement is a persistence and review loop, not model-weight training. Treat the official repository release list and documentation as the source of truth; this reference is a conceptual port and must be rechecked when Hermes changes.

## Durable state

- Persistent memory uses bounded MEMORY.md for agent notes and USER.md for the user profile. Both are injected at session start.
- The memory tool supports add, replace, and remove; it has no read action because current memory is already in context. Current Hermes documentation describes configurable limits of 2,200 and 1,375 characters by default.
- Memory rejects exact duplicates and scans entries for prompt-injection, exfiltration, and invisible-character patterns.
- session_search keeps full session history in SQLite with FTS5. It returns actual messages without an LLM call and is the place to retrieve details that do not belong in bounded always-on memory.
- Skills are on-demand procedural memory. They are loaded only when relevant and may be found in the primary skills directory or configured external directories.

## Skill management

Hermes skill_manage supports create, patch, edit, delete, write_file, and remove_file. Patch is preferred for targeted updates; supporting files are managed separately from SKILL.md. Skill writes can be gated with skills.write_approval, in which case writes are staged for explicit review. An optional guard can scan agent-created skill content for dangerous patterns.

The self-improvement loop should:

1. Finish the foreground task and verify its result.
2. Review durable lessons when the work was complex, hit a recoverable error, exposed a reusable workflow, or included a user correction.
3. Classify each lesson once: repeatable procedure goes to a skill, user preference or communication style goes to USER.md, and environment/project fact goes to MEMORY.md. If nothing is durable, save nothing.
4. Patch an existing skill before creating a new one.
5. Avoid duplicating one fact across stores and keep operational usage data outside the skill text.

## Background review

After a turn, Hermes may run a non-blocking self-improvement fork that decides whether to save a memory or create or patch a skill. The review can be assigned through auxiliary.background_review; when it uses a different model, Hermes sends a compact digest instead of replaying the full conversation, and the review cadence can adapt. The review can surface a short change notification; memory.write_approval and skills.write_approval can stage writes before they land.

The foreground task must not depend on this fork having run. A successful task, its verification evidence, and the explicit mutation boundary remain the source of truth.

## Current learning surfaces

- /learn turns a described workflow, directory, or URL into a reusable skill.
- /journey shows the accumulated memory and skill history and allows learned nodes to be edited or deleted; skill deletion is recoverable through the archive path.
- These surfaces are Hermes features, not available Codex tools unless the current environment exposes them.

## Curator

Curator is a separate background maintenance pass:

- It tracks usage in .usage.json, including views, uses, patches, last activity, lifecycle state, provenance, and pinning.
- It is triggered by inactivity checks at session start or gateway ticks, requiring both an elapsed interval and sufficient idle time; it is not a cron daemon.
- Deterministic transitions mark long-unused skills stale and archive them later. The default thresholds are 30 days for stale and 90 days for archive, but configuration controls them.
- Pinned skills and skills referenced by any cron job are skipped. Hub-installed skills are off-limits. Unused bundled skills may be pruned only when the corresponding prune_builtins setting is enabled.
- LLM consolidation is optional and off by default. It may patch or merge overlapping agent-created skills, but it must never be treated as a prerequisite for the foreground task.
- Real runs support dry-run, automatic backup, rollback, pause/resume, pin/unpin, adoption, and archive/restore commands. The auxiliary curator model is configured under auxiliary.curator in current Hermes documentation.
- Provenance matters: background-review-created skills are marked agent-created; foreground/user-directed and hand-written skills are not automatically managed unless explicitly adopted.
- Curator never hard-deletes skills as its normal cleanup action; archival is recoverable.

## Codex transfer

- Use <CODEX_HOME>/skills as procedural memory.
- Use <CODEX_HOME>/memories/CODEX_MEMORY.md for compact declarative facts when the host memory policy authorizes a memory update.
- Use <CODEX_HOME>/AGENTS.md for short always-on rules, not detailed workflows.
- Codex currently has no native Hermes background fork, session_search, skill_manage, or curator runtime. Do not simulate their side effects or report them as active.
- Apply the host's explicit-authorization boundary: a request to update this skill authorizes the scoped skill edit, but not an unrelated memory write, deployment, or destructive consolidation.
- After edits, validate the skill folder and inspect agents/openai.yaml whenever the trigger or interface metadata changed.

## Upstream audit checklist

When refreshing this reference:

1. Check the official Hermes release list and current memory, skills, and curator documentation.
2. Separate newly released behavior from stable concepts and preserve only reusable, class-level guidance.
3. Record version-specific findings in the handoff, not as a permanent date-stamped claim inside this reference.
4. Keep Codex differences explicit so a future reader does not infer unavailable Hermes tools.
5. Run the Codex skill validator after every mutation.

Official sources:

- https://github.com/NousResearch/hermes-agent/releases
- https://hermes-agent.nousresearch.com/docs/user-guide/features/memory/
- https://hermes-agent.nousresearch.com/docs/user-guide/features/skills
- https://hermes-agent.nousresearch.com/docs/user-guide/features/curator
