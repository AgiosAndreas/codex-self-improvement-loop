---
name: self-improvement-loop
description: Use when Codex should persist durable lessons from a session, make itself better for future work, update or create Codex skills after complex tasks, incorporate user corrections, capture a non-trivial workflow, update compact memory, review whether an existing skill was missing steps, wrong, stale, or too narrow, synchronize this Hermes-derived port with upstream Hermes, or install this port from a public or secret GitHub Gist or published GitHub bundle. Also use when the user asks about Hermes-style self-improvement, persistent memory, periodic remembering, skill curation, or making Codex "self-improving".
---

# Self Improvement Loop

## Core Rule

Treat self-improvement as persistent context, not model training. Persist durable procedures as Codex skills and durable declarative facts in <CODEX_HOME>/memories/CODEX_MEMORY.md; keep transient task state out of both.

Prefer this order:

1. Patch an existing relevant skill.
2. Add a focused reference file under an existing skill.
3. Update compact memory for stable user/environment facts.
4. Create a new class-level skill only when no existing skill covers the workflow.
5. Leave nothing behind when the lesson is a one-off, stale soon, secret, or easily rediscovered.

## Codex boundaries

Treat Hermes as a reference implementation, not as a promise that the same tools or background workers exist in Codex.

- Keep skill changes scoped to the user's request and use the available Codex editing and validation tools.
- Do not silently write memory files. Follow the host memory policy and require explicit user authorization for persistent memory changes.
- Do not claim that a Hermes background review, session search, curator, or auxiliary model is running in Codex unless current tools or runtime evidence proves it.
- Preserve the separation between procedural knowledge in skills and stable declarative facts in memory.

## Synchronize with Hermes

When asked to synchronize this port with Hermes:

1. Check the official Hermes release list and the current Memory, Skills, and Curator documentation. Treat the newest published release as the stable baseline and the main-branch documentation as potentially newer; state which one supports each proposed change.
2. If a local Hermes checkout is explicitly in scope, inspect its version, current branch, remote, and working tree before reading it. Fetch or update that checkout only with explicit authorization. Do not run a Hermes installer or copy its .hermes state as part of a skill sync.
3. Compare behavior by capability: memory versus user-profile routing, skill management and write approval, background review and auxiliary models, session search, learning surfaces, and Curator lifecycle/provenance. Distinguish upstream behavior from features actually available in Codex.
4. Keep Codex-specific paths, memory authorization rules, tool boundaries, and validation requirements authoritative. Never copy credentials, session databases, user memory, usage telemetry, or implementation-specific state from Hermes.
5. Update references/hermes-patterns.md with reusable, evergreen concepts. Keep release numbers and audit dates in the handoff; do not hardcode a dated upstream snapshot into the class-level workflow.
6. Make the smallest useful patch. Update SKILL.md when the sync procedure or trigger changes; update agents/openai.yaml when its user-facing metadata becomes stale.
7. Validate the full skill directory, inspect the final diff, and report the upstream source, version or branch checked, files changed, checks passed, and any Hermes capabilities that remain unavailable in Codex.

For a local checkout, use read-only inspection first:

    hermes --version
    git -C <hermes-checkout> status --short --branch
    git -C <hermes-checkout> remote -v
    git -C <hermes-checkout> describe --tags --always

Only after explicit authorization to refresh that checkout may the workflow use git fetch --tags --prune. A fetch updates local refs but does not itself prove that the installed Hermes runtime changed.

## Transfer and install

The portable unit is this skill directory, not the whole Codex profile. Publish or copy the complete folder contents, including SKILL.md, agents/openai.yaml, references/hermes-patterns.md, and scripts/install_from_gist.py. A published bundle may keep this directory at its root or inside exactly one parent directory; the installer locates the single SKILL.md.

Do not transfer CODEX_MEMORY.md, session history, auth.json, `.hermes` state, tokens, telemetry, or unrelated skills. Those are host-specific or sensitive. This skill transfers procedures; it does not transfer the accumulated memory of the original Codex.

Use scripts/install_from_gist.py for a GitHub Gist or a public/private GitHub repository clone. It validates the frontmatter and refuses to overwrite an existing destination.

Public and secret gists use the same installer. A GitHub secret gist is link-accessible and is not a true private repository: anyone who obtains the URL can read or clone it. Do not put tokens in a gist URL or in gist contents. Use a private GitHub repository instead when access control is required.

Install directly from a Gist URL:

    python3 scripts/install_from_gist.py https://gist.github.com/<gist-id>.git

Install directly from a GitHub repository and branch:

    python3 scripts/install_from_gist.py --ref <branch-or-tag> https://github.com/<owner>/<repo>.git

Install from an already cloned bundle:

    python3 scripts/install_from_gist.py --source /path/to/cloned-bundle

The installer defaults to <CODEX_HOME>/skills, or ~/.codex/skills when CODEX_HOME is unset. Use --dest to select another skills root and --name to override the name from SKILL.md. After installation, restart Codex or reload its skills and run the standard skill validator when available.

For prompt-first transfer, give the receiving Codex the published bundle URL and ask it to read this section, clone the source, run the installer, validate the installed directory, and report the destination. If the destination already exists, it must stop and ask before changing it.

## Review Triggers

Run this review before final response or immediately after a task when any trigger fired:

- The task required roughly 5+ tool calls or involved debugging, retries, approvals, or non-obvious setup.
- The user corrected style, workflow, assumptions, formatting, or expected behavior.
- A reusable command sequence, API quirk, verification pattern, or project convention emerged.
- A loaded skill was incomplete, stale, too broad, too narrow, or had wrong instructions.
- The user explicitly asked Codex to remember a procedure or improve future behavior.
- Several turns passed with new user preferences or stable environment facts that would reduce repeated steering later.

## What To Save Where

Save in skills:

- How to perform a recurring workflow in this user's environment.
- Exact commands, checks, file locations, or approval patterns that are stable.
- Pitfalls and their fixes when the fix is likely to recur.
- User preferences that change how a class of task should be executed.

Save in `<CODEX_HOME>/memories/CODEX_MEMORY.md`:

- Stable user preferences, expectations, and recurring corrections.
- Stable environment facts: OS, shells, important directories, recurring tools, durable service/project facts.
- Short declarative notes that prevent the user from repeating themselves.

Do not save:

- Credentials, tokens, secrets, private raw logs, or personal sensitive details.
- PR numbers, commit hashes, "today we fixed X", or other task progress.
- Fresh-install failures, missing binaries, or temporary environment breakage unless the fix is a reusable setup step.
- Negative blanket claims like "tool X does not work"; capture the recovery path instead.

## Memory Review Workflow

Use this for Hermes-like periodic remembering:

1. Read `<CODEX_HOME>/memories/CODEX_MEMORY.md` when the request depends on prior preferences, environment, or "what we usually do".
2. At the end of complex or corrective sessions, review whether any stable fact belongs in memory.
3. Patch existing entries instead of appending duplicates.
4. Keep entries short, declarative, and current. Prefer one dense line over a narrative.
5. Keep task procedures in skills; use memory only for facts about the user, environment, and stable conventions.

## Skill Update Workflow

1. Inspect available skills and pick the closest umbrella.
2. Read the candidate skill's `SKILL.md`; read references only if needed.
3. Patch the smallest useful change with `apply_patch`.
4. Keep the skill class-level. Avoid task names, issue IDs, one-off codenames, or dates.
5. Add a reference file only for details that would bloat `SKILL.md`.
6. Run the skill validator:

```bash
/usr/bin/python3 <CODEX_HOME>/skills/.system/skill-creator/scripts/quick_validate.py <CODEX_HOME>/skills/<skill-name>
```

7. If the skill's trigger description or user-facing behavior changed, inspect agents/openai.yaml and regenerate its interface metadata with generate_openai_yaml.py when stale, then run the validator again.

## Creating A New Skill

Create a new skill only after checking that no existing skill is a good home.

Use the skill creator workflow:

```bash
/usr/bin/python3 <CODEX_HOME>/skills/.system/skill-creator/scripts/init_skill.py <skill-name> --path <CODEX_HOME>/skills
```

Then replace the template with:

- Frontmatter with `name` and a trigger-rich `description`.
- A concise workflow.
- Pitfalls and verification steps.
- Optional `references/` files for detailed reusable knowledge.

Validate the result with `quick_validate.py`.

## Periodic Curation

When asked to audit or curate skills:

1. List non-system skills under `<CODEX_HOME>/skills`.
2. Identify duplicates, stale narrow skills, and umbrella candidates.
3. Prefer consolidation by patching the umbrella, then remove only clearly redundant material after user approval.
4. Keep system skills and plugin-provided skills intact unless the user explicitly asks otherwise.
5. Report what was changed and what should be watched.

For the Hermes source pattern behind this skill, read `references/hermes-patterns.md`.
